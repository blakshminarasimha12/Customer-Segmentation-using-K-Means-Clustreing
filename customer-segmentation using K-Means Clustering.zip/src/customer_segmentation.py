import os
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE_DIR, "data", "customers.csv")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 1. Load data
df = pd.read_csv(DATA_PATH)

# 2. Basic preprocessing
df = df.drop_duplicates().copy()
df["Gender"] = df["Gender"].map({"Male": 0, "Female": 1})

features = ["Age", "Annual_Income", "Spending_Score", "Purchase_Frequency"]
X = df[features].copy()

# 3. Scale features because they have different ranges
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# 4. Elbow Method
wcss = []
k_values = range(2, 11)

for k in k_values:
    model = KMeans(n_clusters=k, random_state=42, n_init=10)
    model.fit(X_scaled)
    wcss.append(model.inertia_)

plt.figure(figsize=(8, 5))
plt.plot(list(k_values), wcss, marker="o")
plt.title("Elbow Method for Optimal K")
plt.xlabel("Number of Clusters (K)")
plt.ylabel("WCSS")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "elbow_method.png"), dpi=200)
plt.close()

# 5. Train K-Means
# K=4 is used for this academic demonstration after inspecting the elbow plot.
kmeans = KMeans(n_clusters=4, random_state=42, n_init=10)
df["Cluster"] = kmeans.fit_predict(X_scaled) + 1

# 6. Cluster summary
summary = df.groupby("Cluster")[features].mean().round(2)
summary["Customer_Count"] = df["Cluster"].value_counts().sort_index()
summary.to_csv(os.path.join(OUTPUT_DIR, "cluster_summary.csv"))

# 7. Cluster visualization
plt.figure(figsize=(9, 6))
sns.scatterplot(
    data=df,
    x="Annual_Income",
    y="Spending_Score",
    hue="Cluster",
    palette="viridis",
    s=80
)
plt.title("Customer Segmentation: Income vs Spending Score")
plt.xlabel("Annual Income (₹)")
plt.ylabel("Spending Score")
plt.legend(title="Cluster")
plt.tight_layout()
plt.savefig(os.path.join(OUTPUT_DIR, "customer_clusters.png"), dpi=200)
plt.close()

# 8. Save segmented data
df.to_csv(os.path.join(OUTPUT_DIR, "segmented_customers.csv"), index=False)

print("Customer segmentation completed successfully.")
print("\nCluster Summary:")
print(summary)
print("\nGenerated files are available in the outputs/ folder.")
